<?php

// Include CSS for Paper Bootstrap Wizard
msv_include(CONTENT_URL."/css/paper-bootstrap-wizard.css", $this->activationUrl);

// Include JS for Paper Bootstrap Wizard
msv_include(CONTENT_URL."/js/jquery.bootstrap.wizard.js", $this->activationUrl);
msv_include(CONTENT_URL."/js/paper-bootstrap-wizard.js", $this->activationUrl);


